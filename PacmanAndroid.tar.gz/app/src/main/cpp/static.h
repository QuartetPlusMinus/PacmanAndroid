//
// Created by viewsharp on 04.04.18.
//

#ifndef PACMANANDROID_STATIC_H
#define PACMANANDROID_STATIC_H

void func();

#endif //PACMANANDROID_STATIC_H
