//
// Created by viewsharp on 04.04.18.
//

#include "static.h"
//#include <GLES2/gl2.h>

void func() {
    return;
}