package com.example.viewsharp.pacman;

/*
 * Created by viewsharp on 22.03.18.
 */

import static android.opengl.GLES20.*;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class GameLibJNIWrapper {
    static {
        System.loadLibrary("game");
    }

//    public static void onSurfaceCreated() {
//        glClearColor(0.0f, 0.0f, 1.0f, 0.0f);
//    }
//
//    public static void onSurfaceChanged(int width, int height) {
//        // No-op
//    }
//
//    public static void onDrawFrame() {
//        glClear(GL_COLOR_BUFFER_BIT);
//    }

    public static native void onSurfaceCreated();

    public static native void onSurfaceChanged(int width, int height);

    public static native void onDrawFrame();
}
