//
// Created by viewsharp on 22.03.18.
//

#ifndef TEXPARK_PACMAN_GLWRAPPER_H_H
#define TEXPARK_PACMAN_GLWRAPPER_H_H

#include <GLES3/gl3.h>

#endif //TEXPARK_PACMAN_GLWRAPPER_H_H
